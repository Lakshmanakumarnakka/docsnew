import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  totalAmount:any
  constructor() { }
  
  lat: number 
  lng: number 
  ngOnInit() {
    this.totalAmount=window.history.state.totalAmount
    navigator.geolocation.getCurrentPosition
    navigator.geolocation.watchPosition((position) => {
     this.lat = position.coords.latitude
     this.lng = position.coords.longitude
    });
  
  }

  public payuform: any = {};
  disablePaymentButton: boolean = true;
  title: string = 'My first AGM project';
  confirmPayment() {
    const paymentPayload = {
      email: this.payuform.email,
      name: this.payuform.firstname,
      phone: this.payuform.phone,
      productInfo: this.payuform.productinfo,
      amount:  this.totalAmount
    }

  }
 

}
