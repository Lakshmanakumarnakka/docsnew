import { Component, OnInit, ViewChild } from '@angular/core';
import { OrderService }  from './../../services/order.service'
// import { PapaParseParser } from 'ngx-papaparse';
import {  Router } from '@angular/router';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  orders: any[] = [];
  selectedItemList: any[] = [];
  test = [];
  subTotal:number=0;
  salesTax:number=0;
  grandTotal:number=0;

  constructor(private orderService: OrderService,public router: Router) { }

  ngOnInit() {
    this.orderService.getOrders().subscribe((data : any[])=>{
        console.log(data);
        this.orders = data;
    })
  }
  AddOrder(orderId:any){
     let selectedObject =  this.orders.filter(function(order) {
      return order.id == orderId;
    });
    this.subTotal=0;
    this.salesTax=0;
    this.selectedItemList.push(selectedObject[0]);
    this.selectedItemList.map(item=>{
      this.subTotal+=item.price;
    })
    
    this.salesTax+=this.subTotal/10;
    this.grandTotal=this.salesTax+this.subTotal;
    
  }
  // handleFileSelect(evt) {
  //   var files = evt.target.files; // FileList object
  //   var file = files[0];
  //   var reader = new FileReader();
  //   reader.readAsText(file);
  //   reader.onload = (event: any) => {
  //     var csv = event.target.result; // Content of CSV file

  //     // let results = this.papa.parse(csv,0,true)
  //     //     for (let i = 0; i < results.data.length; i++) {
  //     //       let orderDetails = {
  //     //         order_id: results.data[i].Address,
  //     //         age: results.data[i].Age
  //     //       };
  //     //      this.test.push(orderDetails);
  //     //     }
  //     //     // console.log(this.test);
  //     //     console.log('Parsed: k', results.data);
        
  //     }
    
  // }
  navigateWithState() {
    this.router.navigateByUrl('/checkout', { state: { totalAmount: this.grandTotal } });
  }
}

