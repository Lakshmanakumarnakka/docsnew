import { Injectable } from '@angular/core';
import {InMemoryDbService} from 'angular-in-memory-web-api'

@Injectable({
  providedIn: 'root'
})
export class DataService  implements InMemoryDbService {

  constructor() { }
  createDb(){

    let  orders =  [
      {id:1,name:"biryani",price:100.00},
      {id:24,name:"Supreme Pizza",price:16.99},
      {id:25,name:"BBQ Chicken Pizza",price:14.99},
      {id:26,name:"Veggie Pizza",price:12.99},
      {id:27,name:"Meat Lover's Pizza",price:17.99},
      {id:28,name:"Hawaiian Pizza",price:14.99},
      {id:29,name:"Supreme Calzone",price:8.99},
      {id:30,name:"BBQ Chicken Calzone",price:7.99},
      {id:31,name:"Veggie Calzone",price:6.99},
      {id:32,name:"Meat Lover's Calzone",price:8.99},
      {id:33,name:"Hawaiian Calzone",price:7.99},
      {id:34,name:"Side Salad",price:3.99},
      {id:35,name:"Ceasar Salad",price:4.99},
      {id:36,name:"Cobb Salad",price:4.99},
      {id:37,name:"Chef Salad",price:5.99},
      {id:38,name:"Grilled Cheese",price:3.99},
      {id:39,name:"Coke",price:1.00},
      {id:40,name:"Diet Coke",price:1.00},
      {id:41,name:"Sprite",price:1.00},
      {id:42,name:"Dr. Pepper",price:1.00},
      {id:43,name:"Root Beer",price:1.00}]
 
    return {orders};
 
   }
}
